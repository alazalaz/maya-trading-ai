rootProject.name = "MayaTradingAI"
include(":app")
