package com.maya.tradingai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MayaTradingAIApp()
        }
    }
}

@Composable
fun MayaTradingAIApp() {
    var log by remember { mutableStateOf("Uygulama başlatıldı. Maya sana Türkçe konuşacak.") }
    var input by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("Henüz konuşmadınız.") }

    Scaffold(
        topBar = { SmallTopAppBar(title = { Text("Maya Trading AI") }) },
        content = { padding ->
            Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
                Text("Sohbet Log:")
                Spacer(modifier = Modifier.height(4.dp))
                Text(log, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Sen yaz veya konuş") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = {
                    // Stub for voice chat response
                    response = "Maya (simülasyon): "$input" ile ilgili cevap veriyor."
                    log += "\n$response"
                    input = ""
                }) {
                    Text("Gönder / Konuş")
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text("Son cevap: $response", style = MaterialTheme.typography.bodyMedium)
            }
        }
    )
}
