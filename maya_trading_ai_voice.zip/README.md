# Maya Trading AI - Android Prototip

Bu proje, Maya'nın tam sesli Türkçe sohbetli Android uygulamasının prototipidir.
GitHub Actions ile tek tıkla APK üretilebilir.

## Kullanım
1. GitHub hesabına giriş yap.
2. Bu projeyi kendi repona yükle.
3. Actions sekmesinden workflow'u çalıştır.
4. "app-debug.apk" indir ve telefonuna yükle.

## Özellikler
- Görsel arayüz
- Tam sesli Türkçe sohbet (stub / simülasyon)
- Finansal analiz örnekleri (stub)
